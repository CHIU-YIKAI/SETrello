import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // tell angular the component should be put in <app-root> in index.html
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'frontEnd';
}
